import { Mail, Menu, X } from 'lucide-react'
import { motion } from 'framer-motion'
import { useEffect, useRef, useState } from 'react'

const navItems = [
  { label: 'ABOUT', href: '#about' },
  { label: 'CUSTOMERS', href: '#customers' },
  { label: 'PROJECTS', href: '#projects' },
  { label: 'CONTACT', href: '#contact' },
]

const services = [
  {
    number: '01',
    title: '3D MODELING',
    description:
      'Creation of detailed objects, characters, or environments tailored to specific client needs, ideal for games, products, and visualizations.',
  },
  {
    number: '02',
    title: '3D RENDERING',
    description:
      'High quality, photorealistic renders that showcase designs with realistic lighting, textures, and shadows that bring concepts to life.',
  },
  {
    number: '03',
    title: 'CHARACTER DESIGN',
    description:
      'Unique and expressive character designs for games, animations, NFTs, and digital media with attention to personality and detail.',
  },
  {
    number: '04',
    title: '3D ANIMATION',
    description:
      'Smooth and dynamic animations for characters, products, and abstract visuals, perfect for marketing, games, and entertainment.',
  },
  {
    number: '05',
    title: 'PRODUCT VISUALIZATION',
    description:
      'Stunning 3D product renders for e-commerce, advertising, and presentations that showcase products in the best possible light.',
  },
  {
    number: '06',
    title: 'ART DIRECTION',
    description:
      'Visual systems, mood exploration, and concept development built to make every frame unforgettable.',
  },
]

const projects = [
  {
    number: '01',
    client: 'Skyline Studios',
    liveLabel: 'LIVE PROJECT',
    images: ['/skyline-1.jpg', '/skyline-2.jpg', '/skyline-3.jpg'],
  },
  {
    number: '02',
    client: 'MetaForm Creations',
    liveLabel: 'LIVE PROJECT',
    images: ['/metaform-1.jpg', '/metaform-2.jpg', '/metaform-3.jpg'],
  },
  {
    number: '03',
    client: 'Nova Atelier',
    liveLabel: 'LIVE PROJECT',
    images: ['/projectx-1.jpg', '/projectx-2.jpg', '/projectx-3.jpg'],
  },
]

const testimonials = [
  {
    image: '/testimonial-1.jpg',
    name: 'Michael T.',
    company: 'Protosphere Innovations',
    review:
      'Alex brought our product concept to life in a way we never thought possible. The 3D model was so detailed and realistic, it helped us secure investors and streamline the manufacturing process. Highly recommend!',
  },
  {
    image: '/testimonial-2.jpg',
    name: 'David R.',
    company: 'Apex Interactive',
    review:
      "Alex's 3D character designs exceeded all our expectations. The level of detail, creativity, and responsiveness throughout the project was outstanding. Our game wouldn't be the same without their contributions.",
  },
  {
    image: '/testimonial-3.jpg',
    name: 'Rachel M.',
    company: 'MetaForm Creations',
    review:
      "Alex's unique 3D designs made our NFT collection a huge success. The art was breathtaking, and their professionalism made the entire process smooth and enjoyable. Looking forward to collaborating again!",
  },
  {
    image: '/testimonial-4.jpg',
    name: 'Dr. Amanda K.',
    company: 'MedTech Visuals B',
    review:
      "Alex created detailed 3D models for our medical training program, and the quality was outstanding. The models were precise, realistic, and incredibly useful for our team. We're thrilled with the outcome.",
  },
  {
    image: '/testimonial-5.jpg',
    name: 'Jasper K.',
    company: 'Studio Partner',
    review: 'The 3D work was perfect and brought our vision to life and pre...',
  },
  {
    image: '/testimonial-6.jpg',
    name: 'MedTech Visuals',
    company: 'Healthcare Team',
    review:
      "...tailed 3D models for our medical in, and the quality was outstanding. We're precise, realistic, and incredibly c're thrilled with the outcome...",
  },
]

type FormState = {
  name: string
  email: string
  message: string
}

type FormErrors = Partial<FormState>

function App() {
  const appRef = useRef<HTMLDivElement | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [activeSection, setActiveSection] = useState('')
  const [formData, setFormData] = useState<FormState>({ name: '', email: '', message: '' })
  const [errors, setErrors] = useState<FormErrors>({})
  const [successMessage, setSuccessMessage] = useState('')

  useEffect(() => {
    const root = appRef.current
    if (!root) return

    const navbar = root.querySelector('.navbar') as HTMLElement | null
    const navLinks = Array.from(root.querySelectorAll('.nav-link')) as HTMLElement[]
    const scrollTargets = Array.from(root.querySelectorAll('a[href^="#"], button[data-scroll-target]')) as HTMLElement[]
    const animatedElements = Array.from(root.querySelectorAll('.animate-on-scroll')) as HTMLElement[]
    const sections = Array.from(root.querySelectorAll('section[id]')) as HTMLElement[]

    const handleSmoothScroll = (event: Event) => {
      const currentTarget = event.currentTarget as HTMLElement | null
      const href = currentTarget?.getAttribute('href') ?? currentTarget?.getAttribute('data-scroll-target')
      if (!href?.startsWith('#')) return
      const target = root.querySelector(href)
      if (!target) return
      event.preventDefault()
      target.scrollIntoView({ behavior: 'smooth' })
      setMenuOpen(false)
    }

    scrollTargets.forEach((target) => target.addEventListener('click', handleSmoothScroll))

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in')
          }
        })
      },
      { threshold: 0.1 },
    )

    animatedElements.forEach((element) => observer.observe(element))

    const onScroll = () => {
      const isScrolled = window.scrollY > 50
      setScrolled(isScrolled)

      if (navbar) {
        navbar.style.background = isScrolled ? 'rgba(0,0,0,0.95)' : 'transparent'
        navbar.style.backdropFilter = isScrolled ? 'blur(20px)' : 'none'
      }

      sections.forEach((section, index) => {
        const rect = section.getBoundingClientRect()
        if (rect.top <= 100 && rect.bottom >= 100) {
          setActiveSection(`#${section.id}`)
          navLinks.forEach((link) => link.classList.remove('active'))
          navLinks[index]?.classList.add('active')
        }
      })
    }

    onScroll()
    window.addEventListener('scroll', onScroll)

    return () => {
      window.removeEventListener('scroll', onScroll)
      scrollTargets.forEach((target) => target.removeEventListener('click', handleSmoothScroll))
      animatedElements.forEach((element) => observer.unobserve(element))
      observer.disconnect()
    }
  }, [])

  const handleNavClick = (href: string) => {
    setMenuOpen(false)
    const target = document.querySelector(href)
    target?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleInputChange = (field: keyof FormState, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    setErrors((prev) => ({ ...prev, [field]: undefined }))
    setSuccessMessage('')
  }

  const showError = (field: keyof FormState, message: string) => {
    setErrors((prev) => ({ ...prev, [field]: message }))
  }

  const validateForm = () => {
    const nextErrors: FormErrors = {}
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    let valid = true

    if (!formData.name.trim()) {
      nextErrors.name = 'Name is required'
      valid = false
    }
    if (!formData.email.trim() || !emailRegex.test(formData.email)) {
      nextErrors.email = 'Valid email required'
      valid = false
    }
    if (!formData.message.trim()) {
      nextErrors.message = 'Message is required'
      valid = false
    }

    setErrors(nextErrors)
    if (nextErrors.name) showError('name', nextErrors.name)
    if (nextErrors.email) showError('email', nextErrors.email)
    if (nextErrors.message) showError('message', nextErrors.message)

    return valid
  }

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!validateForm()) return

    setSuccessMessage("Thank you! I'll get back to you soon! 🎉")
    setFormData({ name: '', email: '', message: '' })
    setErrors({})
  }

  return (
    <div ref={appRef} className="min-h-screen overflow-x-hidden bg-[var(--color-bg-dark)] text-[var(--color-text-dark)] transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)]">
      <nav
        className="navbar fixed top-0 left-0 z-50 w-full transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)]"
        style={{
          background: scrolled ? 'rgba(0,0,0,0.95)' : 'transparent',
          backdropFilter: scrolled ? 'blur(20px)' : 'none',
          borderBottom: scrolled ? '1px solid rgba(255,255,255,0.1)' : '1px solid transparent',
        }}
      >
        <div className="mx-auto flex h-[70px] max-w-[1400px] items-center justify-between px-5 md:h-[80px] md:px-[30px] xl:px-10">
          <button
            onClick={() => handleNavClick('#hero')}
            data-scroll-target="#hero"
            className="font-oswald text-[24px] font-black tracking-[0.1em] text-white"
          >
            AT
          </button>

          <ul className="hidden items-center gap-10 md:flex">
            {navItems.map((item) => (
              <li key={item.href}>
                <button
                  onClick={() => handleNavClick(item.href)}
                  data-scroll-target={item.href}
                  className={`nav-link relative text-[14px] font-semibold uppercase tracking-[0.1em] transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:bg-gradient-to-r hover:from-[var(--color-purple)] hover:to-[var(--color-pink)] hover:bg-clip-text hover:text-transparent ${
                    activeSection === item.href ? 'active text-[var(--color-lime)]' : 'text-white'
                  }`}
                >
                  {item.label}
                  <span
                    className={`absolute -bottom-1 left-0 h-[2px] bg-gradient-to-r from-[var(--color-purple)] to-[var(--color-pink)] transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] ${
                      activeSection === item.href ? 'w-full' : 'w-0'
                    }`}
                  />
                </button>
              </li>
            ))}
          </ul>

          <button className="relative flex h-10 w-10 items-center justify-center md:hidden" onClick={() => setMenuOpen((v) => !v)} aria-label="Toggle menu">
            {menuOpen ? <X size={26} /> : <Menu size={26} />}
          </button>
        </div>

        {menuOpen && (
          <div className="mobile-menu border-t border-white/10 bg-black/95 px-5 py-6 backdrop-blur-xl md:hidden">
            <div className="flex min-h-[calc(100vh-71px)] flex-col items-center justify-center gap-8 text-center">
              {navItems.map((item) => (
                <button
                  key={item.href}
                  onClick={() => handleNavClick(item.href)}
                  data-scroll-target={item.href}
                  className="bg-gradient-to-r from-white to-white bg-clip-text font-oswald text-4xl font-black tracking-[0.18em] text-transparent transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:from-[var(--color-purple)] hover:to-[var(--color-pink)]"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      <main>
        <section id="hero" className="animate-on-scroll relative min-h-screen overflow-hidden px-5 pt-28 md:px-[30px] md:pt-20 xl:px-10">
          <div className="hero-noise absolute inset-0 opacity-30" />
          <div className="hero-grid absolute inset-0 opacity-20" />
          <div className="pointer-events-none absolute inset-0">
            <div className="absolute left-[3%] top-[10%] h-24 w-24 rounded-full bg-[var(--color-purple)] opacity-30 blur-[80px]" />
            <div className="absolute right-[6%] top-[5%] h-24 w-24 rounded-full bg-[var(--color-pink)] opacity-30 blur-[80px]" />
            <div className="absolute bottom-[20%] left-[2%] h-24 w-24 rounded-full bg-[var(--color-lime)] opacity-20 blur-[90px]" />
            <div className="absolute left-1/2 top-[38%] h-[360px] w-[360px] -translate-x-1/2 rounded-full bg-[#4f46e5] opacity-15 blur-[150px]" />
          </div>

          <div className="mx-auto flex min-h-[calc(100vh-7rem)] max-w-[1400px] flex-col items-center justify-center">
            <motion.p
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0, ease: 'easeOut' }}
              className="font-inter text-sm tracking-[0.4em] text-[var(--color-text-secondary-dark)]"
            >
              3D DESIGNER & VISUAL ARTIST
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, x: -100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.05, ease: 'easeOut' }}
              className="mt-4 text-center font-oswald font-black uppercase leading-[0.9] tracking-tight text-white"
              style={{ fontSize: 'clamp(70px, 12vw, 140px)', letterSpacing: '-0.02em' }}
            >
              HI, I'M ALEX
            </motion.h1>

            <motion.div
              initial={{ opacity: 0, y: -50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: 'easeOut' }}
              className="relative z-20 -mt-10 my-4 animate-float md:-mt-16"
            >
              <img
                src="/hero-character.jpg"
                alt="3D Character of Alex Turner"
                className="h-[340px] w-[250px] rounded-[18px] object-contain py-1 md:h-[480px] md:w-[360px] xl:h-[500px] xl:w-[430px]"
                style={{ filter: 'drop-shadow(0 0 60px rgba(123,47,190,0.4))', mixBlendMode: 'lighten' }}
              />
            </motion.div>

            <div className="mt-4 flex w-full flex-col items-center justify-between gap-6 md:-mt-8 md:flex-row md:items-end">
              <motion.p
                initial={{ opacity: 0, x: -100 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2, ease: 'easeOut' }}
                className="max-w-[250px] text-center font-oswald text-[14px] font-bold leading-[1.6] tracking-wide text-white md:text-left md:text-[16px]"
              >
                A 3D DESIGNER PASSIONATE ABOUT CRAFTING BOLD AND MEMORABLE PROJECTS 😎
              </motion.p>

              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4, ease: 'easeOut' }}
                onClick={() => handleNavClick('#contact')}
                data-scroll-target="#contact"
                className="inline-block rounded-full px-10 py-4 font-oswald text-sm font-bold uppercase tracking-[0.1em] text-white transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)]"
                style={{
                  background: 'linear-gradient(135deg, #7B2FBE, #FF6B9D)',
                  boxShadow: '0 4px 20px rgba(123,47,190,0.3)',
                }}
                whileHover={{ scale: 1.05, boxShadow: '0 10px 30px rgba(123,47,190,0.5)' }}
              >
                CONTACT ME
              </motion.button>
            </div>
          </div>
        </section>

        <section id="customers" className="animate-on-scroll px-5 py-[120px] md:px-[30px] xl:px-10">
          <div className="mx-auto max-w-[1400px] rounded-[30px] border border-[var(--color-border-dark)] bg-white/[0.03] p-8 md:p-10">
            <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.7 }}>
              <p className="mb-5 font-inter text-xs uppercase tracking-[0.2em] text-[var(--color-text-secondary-dark)]">CUSTOMERS</p>
              <h2 className="font-oswald text-center text-[clamp(50px,8vw,100px)] font-black uppercase leading-[0.9] tracking-[-0.02em] text-white">TRUSTED BY BOLD BRANDS</h2>
              <p className="mt-6 max-w-[680px] font-inter text-[clamp(14px,1.5vw,18px)] leading-[1.6] text-white/70">
                I collaborate with startups, studios, and creative teams looking for memorable 3D visuals with a premium edge.
              </p>
            </motion.div>
          </div>
        </section>

        <section id="about" className="animate-on-scroll about-section relative overflow-hidden bg-[var(--color-bg-dark)] px-5 py-[120px] md:px-[30px] xl:px-10">
          <div className="pointer-events-none absolute inset-0">
            <div className="about-metal-flower about-shape absolute left-[5%] top-[10%]" />
            <div className="about-crystal about-shape absolute right-[5%] top-[5%]" />
            <div className="about-heart about-shape absolute left-[3%] top-1/2 -translate-y-1/2" />
            <div className="about-daisy about-shape absolute bottom-[20%] right-[8%]" />
          </div>

          <div className="relative mx-auto flex max-w-[1400px] flex-col items-center text-center">
            <motion.h2
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7 }}
              className="font-oswald font-black uppercase leading-[0.9] text-white"
              style={{ fontSize: 'clamp(50px, 8vw, 100px)', letterSpacing: '0.02em' }}
            >
              ABOUT ME
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="mx-auto mt-10 max-w-[700px] font-inter leading-[1.6] text-white/85"
              style={{ fontSize: 'clamp(14px, 1.5vw, 18px)' }}
            >
              With over five years of experience in design, I specialize in branding, web design, and user
              experience. I love collaborating with businesses that want to stand out and showcase their best
              side. Let&apos;s create something amazing together!
            </motion.p>

            <motion.button
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              onClick={() => handleNavClick('#contact')}
              data-scroll-target="#contact"
              className="mt-10 inline-block rounded-full px-10 py-4 font-oswald text-sm font-bold uppercase tracking-[0.1em] text-white transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)]"
              style={{
                background: 'linear-gradient(135deg, #7B2FBE, #FF6B9D)',
                boxShadow: '0 4px 20px rgba(123,47,190,0.3)',
              }}
              whileHover={{ scale: 1.05, boxShadow: '0 10px 30px rgba(123,47,190,0.5)' }}
            >
              CONTACT ME
            </motion.button>
          </div>
        </section>

        <section id="services" className="animate-on-scroll bg-[var(--color-bg-light)] px-5 py-[120px] text-[var(--color-text-light)] md:px-[30px] xl:px-10">
          <div className="mx-auto max-w-[1400px]">
            <motion.div initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.7 }}>
              <h2 className="text-center font-oswald text-[clamp(50px,8vw,100px)] font-black uppercase leading-[0.9] tracking-[-0.02em] text-black">
                SERVICES
              </h2>
            </motion.div>

            <div className="mt-16 border-t border-black/15">
              {services.map((service, index) => (
                <motion.div
                  key={service.number}
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ duration: 0.6, delay: index * 0.06 }}
                  className="group border-b border-[var(--color-border-light)] px-2 py-8 transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:translate-y-[-8px] hover:bg-black/[0.03]"
                >
                  <div className="flex flex-col gap-4 md:flex-row md:items-start">
                    <div className="min-w-[110px] pr-10 font-oswald font-black text-black transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] group-hover:text-[var(--color-purple)]" style={{ fontSize: 'clamp(50px, 7vw, 90px)' }}>
                      {service.number}
                    </div>
                    <div>
                      <h3 className="font-oswald text-[clamp(20px,3vw,32px)] font-black uppercase leading-[1] tracking-[0.04em] text-black">
                        {service.title}
                      </h3>
                      <p className="mt-3 max-w-[500px] font-inter text-[clamp(14px,1.5vw,18px)] leading-[1.6] text-[var(--color-text-secondary-light)]">
                        {service.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section id="projects" className="animate-on-scroll bg-[var(--color-bg-dark)] px-5 py-[120px] md:px-[30px] xl:px-10">
          <div className="mx-auto max-w-[1400px]">
            <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.7 }}>
              <h2 className="text-center font-oswald font-black uppercase leading-[0.9] tracking-[-0.02em] text-white" style={{ fontSize: 'clamp(70px, 12vw, 150px)' }}>
                PROJECTS
              </h2>
            </motion.div>

            <div className="mt-[60px] space-y-6">
              {projects.map((project, index) => (
                <motion.article
                  key={project.client}
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ duration: 0.6, delay: index * 0.12 }}
                  className="rounded-[28px] border-[1.5px] border border-white/20 bg-white/[0.03] p-[30px] transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:bg-white/[0.06] hover:border-white/40"
                >
                  <div className="mb-8 flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
                    <div className="flex items-start gap-5">
                      <div className="font-oswald text-[40px] font-black leading-none text-white md:text-[50px]">
                        {project.number}
                      </div>
                      <div className="pt-1">
                        <p className="font-inter text-xs uppercase tracking-[0.2em] text-[var(--color-text-secondary-dark)]">
                          CLIENT
                        </p>
                        <p className="mt-2 font-inter text-base italic text-white">{project.client}</p>
                      </div>
                    </div>

                    <button className="w-fit rounded-full border-[1.5px] border-white px-7 py-3 font-inter text-xs uppercase tracking-[0.15em] text-white transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:bg-white hover:text-black">
                      {project.liveLabel}
                    </button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="overflow-hidden rounded-[18px] md:col-span-2">
                      <img
                        src={project.images[0]}
                        alt={`${project.client} main render`}
                        className="h-[240px] w-full object-cover transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:scale-[1.02] md:h-[280px]"
                      />
                    </div>
                    <div className="grid gap-4">
                      <div className="overflow-hidden rounded-[18px]">
                        <img
                          src={project.images[1]}
                          alt={`${project.client} render 2`}
                          className="h-[220px] w-full object-cover transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:scale-[1.02]"
                        />
                      </div>
                      <div className="overflow-hidden rounded-[18px]">
                        <img
                          src={project.images[2]}
                          alt={`${project.client} render 3`}
                          className="h-[220px] w-full object-cover transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:scale-[1.02]"
                        />
                      </div>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section id="testimonials" className="animate-on-scroll bg-[var(--color-bg-dark)] px-5 py-[120px] md:px-[30px] xl:px-10">
          <div className="mx-auto max-w-[1400px]">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.6 }}
              className="mb-16 flex items-center justify-center gap-4 text-center"
            >
              <h2 className="font-oswald text-[clamp(36px,5vw,60px)] font-black text-white">
                What Clients Are Saying
              </h2>
              <span className="text-[50px] md:text-[60px]">😍</span>
            </motion.div>

            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {testimonials.map((testimonial, index) => (
                <motion.article
                  key={`${testimonial.name}-${index}`}
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ duration: 0.6, delay: index * 0.08 }}
                  className="rounded-[22px] border-[1.5px] border border-white/15 bg-white/[0.04] p-8 transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:translate-y-[-5px] hover:border-white/35"
                >
                  <div className="flex items-center gap-4">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="h-[60px] w-[60px] rounded-full border-2 border-white/30 object-cover"
                    />
                    <div>
                      <p className="font-inter text-[15px] font-bold text-white">{testimonial.name}</p>
                      <p className="font-inter text-xs uppercase tracking-[0.1em] text-[#AAAAAA]">
                        {testimonial.company}
                      </p>
                    </div>
                  </div>

                  <div className="my-4 h-px bg-white/10" />

                  <p className="font-inter text-[13px] italic leading-[1.7] text-white/75 md:text-[14px]">
                    {testimonial.review}
                  </p>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section id="contact" className="animate-on-scroll relative overflow-hidden bg-white px-5 py-[120px] text-black md:px-[30px] xl:px-10">
          <div className="contact-lightning absolute -right-5 -top-5 hidden md:block" />
          <div className="contact-blob absolute -left-5 bottom-[30%] hidden md:block" />

          <div className="relative mx-auto grid max-w-[1400px] gap-16 lg:grid-cols-2 lg:gap-20">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7 }}
              className="max-w-[520px]"
            >
              <h2 className="font-oswald text-[clamp(40px,6vw,80px)] font-black uppercase leading-[1] text-black">
                LET&apos;S GET IN TOUCH
              </h2>
              <a
                href="mailto:alex@3dturner.com"
                className="mt-8 inline-block font-inter text-[16px] font-medium text-black underline transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:text-[var(--color-purple)] md:text-[18px]"
              >
                alex@3dturner.com
              </a>
            </motion.div>

            <motion.form
              id="contact-form"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              onSubmit={handleSubmit}
              className="space-y-8"
            >
              <div>
                <label className="mb-2 block font-inter text-sm text-gray-500">Name</label>
                <input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  className="w-full border-0 border-b-[1.5px] border-[#CCCCCC] bg-transparent py-3 text-base outline-none transition-colors duration-300 focus:border-black"
                />
                {errors.name && <p className="mt-2 text-sm text-red-500">{errors.name}</p>}
              </div>

              <div>
                <label className="mb-2 block font-inter text-sm text-gray-500">Email</label>
                <input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="w-full border-0 border-b-[1.5px] border-[#CCCCCC] bg-transparent py-3 text-base outline-none transition-colors duration-300 focus:border-black"
                />
                {errors.email && <p className="mt-2 text-sm text-red-500">{errors.email}</p>}
              </div>

              <div>
                <label className="mb-2 block font-inter text-sm text-gray-500">Message</label>
                <textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => handleInputChange('message', e.target.value)}
                  className="min-h-[120px] w-full resize-y border-0 border-b-[1.5px] border-[#CCCCCC] bg-transparent py-3 text-base outline-none transition-colors duration-300 focus:border-black"
                />
                {errors.message && <p className="mt-2 text-sm text-red-500">{errors.message}</p>}
              </div>

              {successMessage && <p className="success-message text-sm font-medium text-green-600">{successMessage}</p>}

              <div className="flex justify-end lg:justify-end">
                <button
                  type="submit"
                  className="rounded-full border-[1.5px] border-black bg-transparent px-[60px] py-[14px] font-oswald text-sm font-bold uppercase tracking-[0.2em] text-black transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:bg-black hover:text-white"
                >
                  SEND
                </button>
              </div>
            </motion.form>
          </div>
        </section>

        <footer className="bg-black px-5 py-[70px] md:px-[30px] lg:px-10">
          <div className="mx-auto max-w-[1400px]">
            <div className="grid gap-12 text-center md:grid-cols-2 md:text-left lg:grid-cols-3">
              <div className="md:col-span-2 lg:col-span-1">
                <h2 className="font-oswald text-[clamp(32px,5vw,56px)] font-black uppercase leading-[0.95] tracking-[0.05em] text-white">
                  ALEX
                  <br />
                  TURNER
                </h2>
              </div>

              <div>
                <p className="mb-4 font-inter text-xs uppercase tracking-[0.2em] text-[#888888]">SOCIAL</p>
                <div className="flex flex-col items-center gap-2 font-inter text-sm leading-[2] text-white md:items-start">
                  {['Instagram', 'Facebook', 'Artstation', 'Deviantart'].map((item) => (
                    <button key={item} className="w-fit text-left transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:text-[var(--color-lime)]">
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="mb-4 font-inter text-xs uppercase tracking-[0.2em] text-[#888888]">CONTACT</p>
                <div className="flex flex-col gap-1 font-inter text-[13px] leading-[2] text-white md:text-[14px]">
                  <a href="mailto:alex@3dturner.com" className="flex items-center justify-center gap-2 transition-[all] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)] hover:text-[var(--color-lime)] md:justify-start">
                    <Mail size={16} /> alex@3dturner.com
                  </a>
                  <span>+1 (555) 123-4567</span>
                  <span>123 Creative Lane, Suite 45</span>
                  <span>Design City, CA 90210</span>
                </div>
              </div>
            </div>

            <div className="mt-12 flex flex-wrap items-center justify-center gap-3 border-t border-white/10 pt-10">
              <div className="footer-shape footer-shape-x" />
              <div className="footer-shape footer-shape-dots" />
              <div className="footer-shape footer-shape-j" />
              <div className="footer-shape footer-shape-purple-circle" />
              <div className="footer-shape footer-shape-arrow-bow" />
              <div className="footer-shape footer-shape-hourglass" />
              <div className="footer-shape footer-shape-up-triangle" />
              <div className="footer-shape footer-shape-ring" />
            </div>

            <div className="mt-10 border-t border-white/10 pt-6 text-center">
              <p className="font-inter text-xs text-[#666666]">© 2024 Alex Turner. All Rights Reserved.</p>
            </div>
          </div>
        </footer>
      </main>
    </div>
  )
}

export default App
